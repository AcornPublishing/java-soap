/**
 * SparePartPriceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis Wsdl2java emitter.
 */

package wroxaxis.chapter2.stubs;

public interface SparePartPriceService extends javax.xml.rpc.Service {
    public String getSparePartPriceAddress();

    public wroxaxis.chapter2.stubs.SparePartPrice getSparePartPrice() throws javax.xml.rpc.ServiceException;

    public wroxaxis.chapter2.stubs.SparePartPrice getSparePartPrice(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
