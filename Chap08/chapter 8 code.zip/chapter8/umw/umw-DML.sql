use umw;

INSERT INTO COMPANYMASTER VALUES ("UMW","123 First Street","","San Jose","CA","95128","info@umw.com","123-4567890","123-0987654","123456789");

INSERT INTO DEALER VALUES (1,"UMW - San Jose","100 First Street","","San Jose","CA","95111","info@umw-sanjose.com","123-4567890","123-4567890","456123789");
INSERT INTO DEALER VALUES (2,"UMW - Sunnyvale","1234 El Camino Real","","Sunnyvale","CA","95049","info@umw-sunnyvale.com","123-4567890","123-4567890","789123456");

INSERT INTO DEALERAPPOINTMENTSERVICE VALUES(1,"http://localhost:5080/Dealer1/services/AppointmentService");
INSERT INTO DEALERAPPOINTMENTSERVICE VALUES(2,"http://localhost:6080/Dealer2/services/AppointmentService");

INSERT INTO SUPPLIER VALUES (1,"GoodLuck Supplier","879 Mission Blvd","","Sacramento","CA","92222","info@goodlucksupplier.com","123-4567890","123-0987654","supplier1","supplier1","666777888");

INSERT INTO SPAREPART VALUES (1,"SKU-1","AIR FILTER",29.99);
INSERT INTO SPAREPART VALUES (2,"SKU-2","AIR MUFFLER",19.99);
INSERT INTO SPAREPART VALUES (3,"SKU-3","SPARK PLUG",3.99);

INSERT INTO SPAREPARTINVENTORY VALUES (1,10,3,2);
INSERT INTO SPAREPARTINVENTORY VALUES (2,20,5,3);
INSERT INTO SPAREPARTINVENTORY VALUES (3,30,10,5);

INSERT INTO SPAREPARTSUPPLIER VALUES (1,1);
INSERT INTO SPAREPARTSUPPLIER VALUES (1,2);
INSERT INTO SPAREPARTSUPPLIER VALUES (1,3);

INSERT INTO CARMODEL VALUES (1,"UMW 7159 A Series","2002","Engine Specs - 6 Cylinder, 2.5 Liter, HP 200","Transmission Specs - Automatic","Warranty Details - 4 year/50,000 miles","12999");
INSERT INTO CARMODEL VALUES (2,"UMW 7159 B Series","2002","Engine Specs - 4 Cylinder, 1.8 Liter, HP 130","Transmission Specs - Automatic","Warranty Details - 4 year/50,000 miles","8999");




