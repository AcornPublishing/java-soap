package com.umw.bo;
import java.util.*;
import java.sql.*;
import com.umw.dao.DealerDAO;
import com.umw.entity.Dealer;
import com.umw.utils.DBConnection;

public class DealerBO {

    public DealerBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            DealerDAO dao = new DealerDAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public Dealer getDealerDetails(int dealerId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            DealerDAO dao = new DealerDAO(conn);
            return dao.findByPrimaryKey(dealerId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public Dealer findByDUNS(String DUNSNum) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            DealerDAO dao = new DealerDAO(conn);
            return dao.findByDUNS(DUNSNum);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

}
