/*
 * DealerAppointmentServiceBO.java
 *
 * Created on March 2, 2002, 7:17 AM
 */

package com.umw.bo;
import java.util.*;
import java.sql.*;
import com.umw.dao.DealerAppointmentServiceDAO;
import com.umw.entity.DealerAppointmentService;
import com.umw.utils.DBConnection;
/**
 *
 * @author  Administrator
 * @version
 */
public class DealerAppointmentServiceBO {

    /** Creates new DealerAppointmentServiceBO */
    public DealerAppointmentServiceBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
          conn = DBConnection.getConnection();
          DealerAppointmentServiceDAO dao = new DealerAppointmentServiceDAO(conn);
          return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public DealerAppointmentService getDealerAppointmentServiceDetails(int dealerId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            DealerAppointmentServiceDAO dao = new DealerAppointmentServiceDAO(conn);
            return dao.findByPrimaryKey(dealerId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

}
