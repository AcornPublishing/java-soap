package com.dealer2.wsclient;
import java.net.URL;
import java.util.*;
import org.apache.axis.client.Service;
import org.apache.axis.client.Call;
import org.apache.axis.encoding.XMLType;

import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.namespace.QName;

public class SparePartOrderServiceClient {
    
    String endPointURL = null;

    /** Creates new SparePartInventoryClient */
    public SparePartOrderServiceClient(String endPointURL) {
        this.endPointURL = endPointURL;
    }

    public boolean placeOrder(String dealerPONum, String partSKU ,String DUNSNum, int partQty) throws Exception {
        try {
              String methodName  = "placeOrder";

              Service service = new Service();
              Call call = (Call) service.createCall();
              call.setTargetEndpointAddress(new java.net.URL(endPointURL));
              call.setOperationName(new QName("SparePartOrderService",methodName));
              call.addParameter("dealerponum",XMLType.XSD_STRING,ParameterMode.PARAM_MODE_IN);
              call.addParameter("partsku",XMLType.XSD_STRING,ParameterMode.PARAM_MODE_IN);
              call.addParameter("dunsnum",XMLType.XSD_STRING,ParameterMode.PARAM_MODE_IN);
              call.addParameter("partqty",XMLType.XSD_INT,ParameterMode.PARAM_MODE_IN);

              call.setReturnType(XMLType.XSD_BOOLEAN);

              Object[] params = new Object[] {dealerPONum, partSKU, DUNSNum, new Integer(partQty)};

              Boolean bResult = (Boolean) call.invoke(params);
              return bResult.booleanValue();
        }
        catch (Exception e) {
            throw e;
        }
    }

    public static void main(String[] args) {
        try {
            SparePartOrderServiceClient client = new SparePartOrderServiceClient("http://localhost:6080/Dealer2/services/SparePartOrderService");
            boolean b = client.placeOrder("PO456","SKU-2","456123789",100);
            System.out.println(b);
        }
        catch (Exception e) {
            System.err.println(e.toString());
        }
    }
}
