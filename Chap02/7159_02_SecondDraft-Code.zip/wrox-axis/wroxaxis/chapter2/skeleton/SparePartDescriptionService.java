/**
 * SparePartDescriptionService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis Wsdl2java emitter.
 */

package wroxaxis.chapter2.skeleton;

public interface SparePartDescriptionService extends javax.xml.rpc.Service {
    public String getSparePartDescriptionAddress();

    public wroxaxis.chapter2.skeleton.SparePartDescription getSparePartDescription() throws javax.xml.rpc.ServiceException;

    public wroxaxis.chapter2.skeleton.SparePartDescription getSparePartDescription(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
