/*
 * CarMaker.java
 *
 * Created on March 2, 2002, 5:34 AM
 */

package com.dealer2.entity;

/**
 *
 * @author  Administrator
 * @version 
 */
public class CarManufacturer {

    /** Creates new CarMaker */
    public CarManufacturer() {
    }
    
    /** Getter for property addressLine1.
     * @return Value of property addressLine1.
     */
    public java.lang.String getAddressLine1() {
        return addressLine1;
    }
    
    /** Setter for property addressLine1.
     * @param addressLine1 New value of property addressLine1.
     */
    public void setAddressLine1(java.lang.String addressLine1) {
        this.addressLine1 = addressLine1;
    }
    
    /** Getter for property addressLine2.
     * @return Value of property addressLine2.
     */
    public java.lang.String getAddressLine2() {
        return addressLine2;
    }
    
    /** Setter for property addressLine2.
     * @param addressLine2 New value of property addressLine2.
     */
    public void setAddressLine2(java.lang.String addressLine2) {
        this.addressLine2 = addressLine2;
    }
    
    /** Getter for property carMakerName.
     * @return Value of property carMakerName.
     */
    public java.lang.String getCarMakerName() {
        return carMakerName;
    }
    
    /** Setter for property carMakerName.
     * @param carMakerName New value of property carMakerName.
     */
    public void setCarMakerName(java.lang.String carMakerName) {
        this.carMakerName = carMakerName;
    }
    
    /** Getter for property city.
     * @return Value of property city.
     */
    public java.lang.String getCity() {
        return city;
    }
    
    /** Setter for property city.
     * @param city New value of property city.
     */
    public void setCity(java.lang.String city) {
        this.city = city;
    }
    
    /** Getter for property email.
     * @return Value of property email.
     */
    public java.lang.String getEmail() {
        return email;
    }
    
    /** Setter for property email.
     * @param email New value of property email.
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }
    
    /** Getter for property fax.
     * @return Value of property fax.
     */
    public java.lang.String getFax() {
        return fax;
    }
    
    /** Setter for property fax.
     * @param fax New value of property fax.
     */
    public void setFax(java.lang.String fax) {
        this.fax = fax;
    }
    
    /** Getter for property phone.
     * @return Value of property phone.
     */
    public java.lang.String getPhone() {
        return phone;
    }
    
    /** Setter for property phone.
     * @param phone New value of property phone.
     */
    public void setPhone(java.lang.String phone) {
        this.phone = phone;
    }
    
    /** Getter for property state.
     * @return Value of property state.
     */
    public java.lang.String getState() {
        return state;
    }
    
    /** Setter for property state.
     * @param state New value of property state.
     */
    public void setState(java.lang.String state) {
        this.state = state;
    }
    
    /** Getter for property zipCode.
     * @return Value of property zipCode.
     */
    public java.lang.String getZipCode() {
        return zipCode;
    }
    
    /** Setter for property zipCode.
     * @param zipCode New value of property zipCode.
     */
    public void setZipCode(java.lang.String zipCode) {
        this.zipCode = zipCode;
    }
    
    /** Getter for property manufacturerId.
     * @return Value of property manufacturerId.
     */
    public int getManufacturerId() {
        return manufacturerId;
    }
    
    /** Setter for property manufacturerId.
     * @param manufacturerId New value of property manufacturerId.
     */
    public void setManufacturerId(int manufacturerId) {
        this.manufacturerId = manufacturerId;
    }
    
    /** Getter for property DUNSNum.
     * @return Value of property DUNSNum.
     */
    public java.lang.String getDUNSNum() {
        return DUNSNum;
    }
    
    /** Setter for property DUNSNum.
     * @param DUNSNum New value of property DUNSNum.
     */
    public void setDUNSNum(java.lang.String DUNSNum) {
        this.DUNSNum = DUNSNum;
    }
    
    int manufacturerId;
    String carMakerName;
    String addressLine1;
    String addressLine2;
    String city;
    String state;
    String zipCode;
    String email;
    String phone;
    String fax;
    String DUNSNum;
}
