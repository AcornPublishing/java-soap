package com.dealer2.dao;
import java.util.*;
import java.sql.*;
import com.dealer2.entity.*;
import com.dealer2.utils.*;

public class CarModelDAO {

    private Connection conn;

    public CarModelDAO(Connection conn) {
        this.conn = conn;
    }
    public ArrayList findAll() throws Exception {
        ArrayList modelList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM CARMODEL";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                CarModel model = new CarModel();
                model.setModelId(rs.getInt("MODELID"));
                model.setModelName(rs.getString("MODELNAME"));
                model.setModelYear(rs.getString("MODELYEAR"));
                model.setModelDesc1(rs.getString("MODELDESC1"));
                model.setModelDesc2(rs.getString("MODELDESC2"));
                model.setModelDesc3(rs.getString("MODELDESC3"));
                model.setModelListPrice(rs.getFloat("MODELLISTPRICE"));
                modelList.add(model);
            }
            return modelList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }

        }
    }
    
    public CarModel findByPrimaryKey(int modelId) throws Exception {
        CarModel model = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM CARMODEL where MODELID=");
        sql.append(String.valueOf(modelId));
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                model = new CarModel();
                model.setModelId(rs.getInt("MODELID"));
                model.setModelName(rs.getString("MODELNAME"));
                model.setModelYear(rs.getString("MODELYEAR"));
                model.setModelDesc1(rs.getString("MODELDESC1"));
                model.setModelDesc2(rs.getString("MODELDESC2"));
                model.setModelDesc3(rs.getString("MODELDESC3"));
                model.setModelListPrice(rs.getFloat("MODELLISTPRICE"));
                return model;
            }
            else {
                throw new Exception("CAR MODEL INFORMATION WAS NOT FOUND");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
