/**
 * SparePartDescriptionSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis Wsdl2java emitter.
 */

package wroxaxis.chapter2.skeleton;

public class SparePartDescriptionSoapBindingImpl implements wroxaxis.chapter2.skeleton.SparePartDescription {
    public java.lang.String getDescription(java.lang.String in0) throws java.rmi.RemoteException {
        return "Toyota Spark Plug";
    }

}
