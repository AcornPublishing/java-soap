package com.dealer1.utils;

import java.util.*;
import java.io.*;
import java.sql.*;

/**
 *
 * @author  Administrator
 * @version 
 */
public class DBConnection {
    
    private Connection conn = null;

    /** Creates new DBConnection */
    public DBConnection() throws Exception {}
    
    public static Connection getConnection() throws Exception {
        Class.forName("org.gjt.mm.mysql.Driver");
        
        String DBURL    = "jdbc:mysql://localhost:3306/dealer1";
        String UserName = "rirani";
        String Password = "rirani";
        
        return DriverManager.getConnection(DBURL,UserName,Password);
    }
}
