package wroxaxis.chapter5;

import org.apache.axis.client.Transport;

public class JMSTransport extends Transport {

    public JMSTransport() {
		transportName = "JMSTransport";
	}
}
