/*
 * SparePartOrderBO.java
 *
 * Created on March 2, 2002, 7:16 AM
 */

package com.umw.bo;
import java.util.*;
import java.sql.*;
import com.umw.dao.SparePartSODAO;
import com.umw.entity.SparePartSO;
import com.umw.utils.DBConnection;
/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePartSOBO {

    /** Creates new SparePartOrderBO */
    public SparePartSOBO() {
    }
    
    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartSODAO dao = new SparePartSODAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public SparePartSO getSODetail(int SOId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartSODAO dao = new SparePartSODAO(conn);
            return dao.findByPrimaryKey(SOId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public boolean placeOrder(String dealerPONum, String partSKU ,String DUNSNum, int partQty) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartSODAO dao = new SparePartSODAO(conn);
            return dao.addOrder(dealerPONum, partSKU, DUNSNum, partQty);
            
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
