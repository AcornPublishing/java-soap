package com.umw.dao;
import java.util.*;
import java.sql.*;
import com.umw.entity.*;
import com.umw.utils.*;

/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePartSODAO {

    private Connection conn;

    /** Creates new SparePartOrderDAO */
    public SparePartSODAO(Connection conn) {
        this.conn = conn;
    }

    public ArrayList findAll() throws Exception {
        ArrayList orderList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM SPAREPARTSO";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                SparePartSO order = new SparePartSO();
                order.setSOId(rs.getInt("SOID"));
                order.setPartId(rs.getInt("PARTID"));
                order.setDealerId(rs.getInt("DEALERID"));
                order.setOrderDate(rs.getString("ORDERDATE"));
                order.setPartQty(rs.getInt("PARTQTY"));
                order.setDealerPONum(rs.getString("DEALERPONUM"));
                orderList.add(order);
            }
            return orderList;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public SparePartSO findByPrimaryKey(int SOId) throws Exception {
        SparePartSO order = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM SPAREPARTSO where SOID=");
        sql.append(String.valueOf(SOId));
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                order = new SparePartSO();
                order.setSOId(rs.getInt("SOID"));
                order.setPartId(rs.getInt("PARTID"));
                order.setDealerId(rs.getInt("DEALERID"));
                order.setOrderDate(rs.getString("ORDERDATE"));
                order.setPartQty(rs.getInt("PARTQTY"));
                order.setDealerPONum(rs.getString("DEALERPONUM"));
                return order;
            }
            else {
                throw new Exception("SPARE PART ORDER INFORMATION WAS NOT FOUND");
            }
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public int getUniqueOrderId() throws Exception {
        int orderId = -1;
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "select max(SOID) as SOID from SPAREPARTSO";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            if (rs.next()) {
                orderId = rs.getInt("SOID") + 1;
                return orderId; 
            }
            else {
               throw new Exception("COULD NOT RETRIEVE UNIQUE ORDERID"); 
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public boolean addOrder(String dealerPONum, String partSKU, String DUNSNum, int partQty) throws Exception {
        
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            //Get the Unique Order Id
            int orderId = getUniqueOrderId();
            
            //Get the PartId by finding the Part based on PartSKU
            SparePartDAO SPDAO = new SparePartDAO(conn);
            SparePart part = SPDAO.findByPartSKU(partSKU);
            
            //Get the DealerId based on the DUNS
            DealerDAO DealerDAO = new DealerDAO(conn);
            Dealer dealer = DealerDAO.findByDUNS(DUNSNum);

            //Insert the record in SPAREPARTORDER
            String currentDateTime = new java.util.Date().toString();
            StringBuffer InsertOrderSQL = new StringBuffer();
            InsertOrderSQL.append("INSERT INTO SPAREPARTSO VALUES (");
            InsertOrderSQL.append(orderId + ",");
            InsertOrderSQL.append(part.getPartId() + ",");
            InsertOrderSQL.append(dealer.getDealerId() + ",");
            InsertOrderSQL.append("'" + currentDateTime + "',");
            InsertOrderSQL.append(partQty + ",");
            InsertOrderSQL.append("'" + dealerPONum + "')");
            stmt = conn.createStatement();
            stmt.execute(InsertOrderSQL.toString());
            return true;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
        
    }
}
