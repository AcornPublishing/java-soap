/*
 * SparePartPriceService.java
 *
 * Created on February 2, 2002, 11:07 AM
 */

package wroxaxis.chapter2;

/**
 *
 * @author  Administrator
 * @version
 */
public class SparePartPrice {

    /** Creates new SparePartPriceService */
    public SparePartPrice() {
    }

    public float getPrice(String PartSKU) {
        return (float)10.99;
    }
}
