package wroxaxis.chapter2.messaging;

import org.w3c.dom.Element;
import org.apache.axis.client.Service;
import org.apache.axis.client.Call;
import org.apache.axis.message.SOAPBodyElement;
import org.apache.axis.utils.XMLUtils;


import java.io.FileInputStream;
import java.io.File;
import java.net.URL;
import java.util.Vector;


public class CatalogPublisherServiceClient {

    public static void main(String[] args) throws Exception {

        String endpointURL = "http://localhost:8080/axis/services/CatalogPublisherService";

	Service service = new Service();
	Call call = (Call) service.createCall();

        call.setTargetEndpointAddress(new URL(endpointURL));
        SOAPBodyElement[] reqSOAPBodyElements = new SOAPBodyElement[1];

        File catalogFile = new File("d:\\wrox-axis\\wroxaxis\\chapter2\\messaging\\catalog.xml");
        FileInputStream fis = new FileInputStream(catalogFile);

        reqSOAPBodyElements[0] = new SOAPBodyElement(XMLUtils.newDocument(fis).getDocumentElement());

        Vector resSOAPBodyElements = (Vector) call.invoke(reqSOAPBodyElements);
        SOAPBodyElement resSOAPBodyElement = null ;
        resSOAPBodyElement = (SOAPBodyElement) resSOAPBodyElements.get(0);

        String response = XMLUtils.ElementToString(resSOAPBodyElement.getAsDOM());
        System.out.println("Received the following XML Response");
        System.out.println("-----------------------------------");
        System.out.println(response);
    }
}
