/**
 * SparePartPrice.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis Wsdl2java emitter.
 */

package wroxaxis.chapter2.stubs;

public interface SparePartPrice extends java.rmi.Remote {
    public float getPrice(java.lang.String in0) throws java.rmi.RemoteException;
}
