package com.umw.bo;
import java.util.*;
import java.sql.*;
import com.umw.dao.SupplierDAO;
import com.umw.entity.Supplier;
import com.umw.utils.DBConnection;

public class SupplierBO {

    /** Creates new CarMakerBO */
    public SupplierBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SupplierDAO dao = new SupplierDAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public Supplier getSupplierDetails(int supplierId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SupplierDAO dao = new SupplierDAO(conn);
            return dao.findByPrimaryKey(supplierId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
