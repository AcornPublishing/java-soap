/*
 * SparePart.java
 *
 * Created on March 2, 2002, 5:35 AM
 */

package com.umw.entity;

/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePart {

    /** Creates new SparePart */
    public SparePart() {
    }
    
    /** Getter for property partId.
     * @return Value of property partId.
     */
    public int getPartId() {
        return partId;
    }
    
    /** Setter for property partId.
     * @param partId New value of property partId.
     */
    public void setPartId(int partId) {
        this.partId = partId;
    }
    
    /** Getter for property partName.
     * @return Value of property partName.
     */
    public java.lang.String getPartName() {
        return partName;
    }
    
    /** Setter for property partName.
     * @param partName New value of property partName.
     */
    public void setPartName(java.lang.String partName) {
        this.partName = partName;
    }
    
    /** Getter for property partPrice.
     * @return Value of property partPrice.
     */
    public float getPartPrice() {
        return partPrice;
    }
    
    /** Setter for property partPrice.
     * @param partPrice New value of property partPrice.
     */
    public void setPartPrice(float partPrice) {
        this.partPrice = partPrice;
    }
    
    /** Getter for property partSKU.
     * @return Value of property partSKU.
     */
    public java.lang.String getPartSKU() {
        return partSKU;
    }
    
    /** Setter for property partSKU.
     * @param partSKU New value of property partSKU.
     */
    public void setPartSKU(java.lang.String partSKU) {
        this.partSKU = partSKU;
    }
    
    int partId;
    String partSKU;
    String partName;
    float partPrice;

}
