/**
 * SparePartDescriptionSoapBindingSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis Wsdl2java emitter.
 */

package wroxaxis.chapter2.skeleton;

public class SparePartDescriptionSoapBindingSkeleton implements wroxaxis.chapter2.skeleton.SparePartDescription,
    org.apache.axis.wsdl.Skeleton {
    private wroxaxis.chapter2.skeleton.SparePartDescription impl;
    private static org.apache.axis.wsdl.SkeletonImpl skel = null;

    public SparePartDescriptionSoapBindingSkeleton() {
        this.impl = new wroxaxis.chapter2.skeleton.SparePartDescriptionSoapBindingImpl();
        init();
    }

    public SparePartDescriptionSoapBindingSkeleton(wroxaxis.chapter2.skeleton.SparePartDescription impl) {
        this.impl = impl;
        init();
    }
    public javax.xml.rpc.namespace.QName getParameterName(String opName, int i) {
        return skel.getParameterName(opName, i);
    }

    public static javax.xml.rpc.namespace.QName getParameterNameStatic(String opName, int i) {
        init();
        return skel.getParameterName(opName, i);
    }

    public javax.xml.rpc.ParameterMode getParameterMode(String opName, int i) {
        return skel.getParameterMode(opName, i);
    }

    public static javax.xml.rpc.ParameterMode getParameterModeStatic(String opName, int i) {
        init();
        return skel.getParameterMode(opName, i);
    }

    public static String getInputNamespaceStatic(String opName) {
        init();
        return skel.getInputNamespace(opName);
    }

    public static String getOutputNamespaceStatic(String opName) {
        init();
        return skel.getOutputNamespace(opName);
    }

    public static String getSOAPAction(String opName) {
        init();
        return skel.getSOAPAction(opName);
    }

    protected static void init() {
        if (skel != null) 
            return;
        skel = new org.apache.axis.wsdl.SkeletonImpl();
        skel.add("getDescription",
                 new javax.xml.rpc.namespace.QName[] {
                   new javax.xml.rpc.namespace.QName("", "return"),
                   new javax.xml.rpc.namespace.QName("", "in0"),
                 },
                 new javax.xml.rpc.ParameterMode[] {
                   javax.xml.rpc.ParameterMode.PARAM_MODE_OUT,
                   javax.xml.rpc.ParameterMode.PARAM_MODE_IN,
                 },
                 "http://localhost:8080/axis/services/SparePartDescription",
                 "http://localhost:8080/axis/services/SparePartDescription",
                 "");
    }

    public java.lang.String getDescription(java.lang.String in0) throws java.rmi.RemoteException
    {
        java.lang.String ret = impl.getDescription(in0);
        return ret;
    }

}
