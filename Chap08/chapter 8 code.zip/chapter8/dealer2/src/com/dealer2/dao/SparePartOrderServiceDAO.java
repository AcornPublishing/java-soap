/*
 * InventoryServiceDAO.java
 *
 * Created on March 2, 2002, 5:44 AM
 */

package com.dealer2.dao;
import java.util.*;
import java.sql.*;
import com.dealer2.entity.*;
import com.dealer2.utils.*;

/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePartOrderServiceDAO {

    private Connection conn;

    public SparePartOrderServiceDAO(Connection conn) {
        this.conn = conn;
    }
    public ArrayList findAll() throws Exception {
        ArrayList orderList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM SPAREPARTORDERSERVICE";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                SparePartOrderService orderService = new SparePartOrderService();
                orderService.setManufacturerId(rs.getInt("MANUFACTURERID"));
                orderService.setOrderServiceURL(rs.getString("ORDERSERVICEURL"));
                orderList.add(orderService);
            }
            return orderList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }

        }
    }
    
    public SparePartOrderService findByPrimaryKey(int manufacturerId) throws Exception {
        SparePartOrderService orderService = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM SPAREPARTORDERSERVICE where MANUFACTURERID=");
        sql.append(String.valueOf(manufacturerId));
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                orderService = new SparePartOrderService();
                orderService.setManufacturerId(rs.getInt("MANUFACTURERID"));
                orderService.setOrderServiceURL(rs.getString("ORDERSERVICEURL"));
                return orderService;
            }
            else {
                throw new Exception("ORDER SERVICE INFORMATION WAS NOT FOUND");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
