package com.umw.wsclient;
import java.net.URL;
import java.util.*;
import org.apache.axis.client.Service;
import org.apache.axis.client.Call;
import org.apache.axis.encoding.XMLType;

import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.namespace.QName;
import org.apache.axis.encoding.ser.BeanSerializerFactory;
import org.apache.axis.encoding.ser.BeanDeserializerFactory;

import com.umw.entity.Appointment;

public class AppointmentServiceClient {
    
    String endPointURL = null;

    /** Creates new SparePartInventoryClient */
    public AppointmentServiceClient(String endPointURL) {
        this.endPointURL = endPointURL;
    }

    public boolean reserveAppointment(int AppointmentId, String customerName) throws Exception {
        try {
              String methodName  = "reserveAppointment";

              Service service = new Service();
              Call call = (Call) service.createCall();
              call.setTargetEndpointAddress(new java.net.URL(endPointURL));
              call.setOperationName(new QName("AppointmentService",methodName));
              call.addParameter("apptid",XMLType.XSD_INT,ParameterMode.PARAM_MODE_IN);
              call.addParameter("customername",XMLType.XSD_STRING,ParameterMode.PARAM_MODE_IN);

              QName qname = new QName("AppointmentService", "Appointment");
              Class cls = com.umw.entity.Appointment.class;
	      call.registerTypeMapping(cls, qname, BeanSerializerFactory.class, BeanDeserializerFactory.class);
              call.setReturnType(XMLType.XSD_BOOLEAN);

              Integer ApptId = new Integer(AppointmentId);
              Object[] params = new Object[] {ApptId,customerName};

              Boolean bResult = (Boolean) call.invoke(params);
              return bResult.booleanValue();
        }
        catch (Exception e) {
            throw e;
        }
    }
    
    public ArrayList getAppointmentsByType (boolean available) throws Exception {
       try {
              String methodName  = "findAppointmentsByType";
              Service service = new Service();
              Call call = (Call) service.createCall();
              call.setTargetEndpointAddress(new java.net.URL(endPointURL));
              call.setOperationName(new QName("AppointmentService",methodName));
              call.addParameter("available",XMLType.XSD_BOOLEAN,ParameterMode.PARAM_MODE_IN);

              QName qname = new QName("AppointmentService", "Appointment");
              Class cls = com.umw.entity.Appointment.class;
	      call.registerTypeMapping(cls, qname, BeanSerializerFactory.class, BeanDeserializerFactory.class);
              call.setReturnType(XMLType.SOAP_ARRAY);
              
              Boolean b = new Boolean(available);
              Object[] params = new Object[] {b};

              Object ApptList = call.invoke(params);
              Object[] list = (java.lang.Object[])org.apache.axis.utils.JavaUtils.convert(ApptList,java.lang.Object[].class);              
              ArrayList ApptArrayList = new ArrayList();
              for (int i = 0;i<list.length;i++) {
                  Appointment appt = (Appointment) list[i];
                  ApptArrayList.add(appt);
              }
              return ApptArrayList;
        }
        catch (Exception e) {
            throw e;
        }
    }
    
    public static void main(String[] args) {
        try {
            AppointmentServiceClient client = new AppointmentServiceClient("http://localhost:6080/website/services/AppointmentService");
            ArrayList list = client.getAppointmentsByType(true);
            Iterator it = list.iterator();
            while (it.hasNext()) {
                Appointment appt = (Appointment) it.next();
                System.out.println(appt.getAppointmentId() + appt.getApptDate() + appt.getApptTime());
            }
            AppointmentServiceClient client1 = new AppointmentServiceClient("http://localhost:5080/website/services/AppointmentService");
            list = client1.getAppointmentsByType(true);
            it = list.iterator();
            while (it.hasNext()) {
                Appointment appt = (Appointment) it.next();
                System.out.println(appt.getAppointmentId() + appt.getApptDate() + appt.getApptTime());
            }
            
            boolean b = client.reserveAppointment(6,"Irani");
            System.out.println(b);
            

        }
        catch (Exception e) {
            System.err.println(e.toString());
        }
    }
}
