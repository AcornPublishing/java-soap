package com.dealer2.dao;

import java.util.*;
import java.sql.*;
import com.dealer2.entity.*;
import com.dealer2.utils.*;

public class CarManufacturerModelDAO {
    
    private Connection conn;

    public CarManufacturerModelDAO(Connection conn) {
        this.conn = conn;
    }
    
    public ArrayList findAll() throws Exception {
        ArrayList modelList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM CARMANUFACTURERMODEL";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                CarManufacturerModel model = new CarManufacturerModel();
                model.setManufacturerId(rs.getInt("MANUFACTURERID"));
                model.setModelId(rs.getInt("MODELID"));
                modelList.add(model);
            }
            return modelList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public ArrayList findAllModelsByManufacturer(int manufacturerId) throws Exception {
        ArrayList modelList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer SQL = new StringBuffer();
        SQL.append("SELECT * FROM CARMANUFACTURERMODEL WHERE MANUFACTURERID=");
        SQL.append(String.valueOf(manufacturerId));
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL.toString());
            while (rs.next()) {
                CarManufacturerModel model = new CarManufacturerModel();
                model.setManufacturerId(rs.getInt("MANUFACTURERID"));
                model.setModelId(rs.getInt("MODELID"));
                modelList.add(model);
            }
            return modelList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

 
}
