/*
 * SparePartInventory.java
 *
 * Created on March 2, 2002, 10:03 AM
 */

package com.dealer2.entity;

/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePartInventory implements java.io.Serializable {

    /** Creates new SparePartInventory */
    public SparePartInventory() {
    }
    
    /** Getter for property minOrderQty.
     * @return Value of property minOrderQty.
     */
    public int getMinOrderQty() {
        return minOrderQty;
    }
    
    /** Setter for property minOrderQty.
     * @param minOrderQty New value of property minOrderQty.
     */
    public void setMinOrderQty(int minOrderQty) {
        this.minOrderQty = minOrderQty;
    }
    
    /** Getter for property partId.
     * @return Value of property partId.
     */
    public int getPartId() {
        return partId;
    }
    
    /** Setter for property partId.
     * @param partId New value of property partId.
     */
    public void setPartId(int partId) {
        this.partId = partId;
    }
    
    /** Getter for property qtyOnHand.
     * @return Value of property qtyOnHand.
     */
    public int getQtyOnHand() {
        return qtyOnHand;
    }
    
    /** Setter for property qtyOnHand.
     * @param qtyOnHand New value of property qtyOnHand.
     */
    public void setQtyOnHand(int qtyOnHand) {
        this.qtyOnHand = qtyOnHand;
    }
    
    /** Getter for property reorderLevel.
     * @return Value of property reorderLevel.
     */
    public int getReorderLevel() {
        return reorderLevel;
    }
    
    /** Setter for property reorderLevel.
     * @param reorderLevel New value of property reorderLevel.
     */
    public void setReorderLevel(int reorderLevel) {
        this.reorderLevel = reorderLevel;
    }
    
    int partId;
    int qtyOnHand;
    int reorderLevel;
    int minOrderQty;

}
