/*
 * SparePartOrderDAO.java
 *
 * Created on March 2, 2002, 5:44 AM
 */

package com.dealer1.dao;
import java.util.*;
import java.sql.*;
import com.dealer1.entity.*;
import com.dealer1.utils.*;

/**
 *
 * @author  Administrator
 * @version
 */
public class SparePartPODAO {

    private Connection conn;

    /** Creates new SparePartOrderDAO */
    public SparePartPODAO(Connection conn) {
        this.conn = conn;
    }

    public ArrayList findAll() throws Exception {
        ArrayList orderList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM SPAREPARTPO";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                SparePartPO order = new SparePartPO();
                order.setPOId(rs.getInt("POID"));
                order.setPONumber(rs.getString("PONUMBER"));
                order.setPartId(rs.getInt("PARTID"));
                order.setManufacturerId(rs.getInt("MANUFACTURERID"));
                order.setOrderDate(rs.getString("ORDERDATE"));
                order.setPartQty(rs.getInt("PARTQTY"));
                orderList.add(order);
            }
            return orderList;
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public SparePartPO findByPrimaryKey(int POId) throws Exception {
        SparePartPO order = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM SPAREPARTPO where POID=");
        sql.append(String.valueOf(POId));
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                order = new SparePartPO();
                order.setPOId(rs.getInt("POID"));
                order.setPONumber(rs.getString("PONUMBER"));
                order.setPartId(rs.getInt("PARTID"));
                order.setManufacturerId(rs.getInt("MANUFACTURERID"));
                order.setOrderDate(rs.getString("ORDERDATE"));
                order.setPartQty(rs.getInt("PARTQTY"));
                return order;
            }
            else {
                throw new Exception("SPARE PART ORDER INFORMATION WAS NOT FOUND");
            }
        }
        catch (Exception e) {
            System.out.println(e.getMessage());
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public int getUniqueOrderId() throws Exception {
        int orderId = -1;
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "select max(POID) as POID from SPAREPARTPO";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            if (rs.next()) {
                orderId = rs.getInt("POID") + 1;
                return orderId;
            }
            else {
               throw new Exception("COULD NOT RETRIEVE UNIQUE PURCHASE ORDER ID");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public String getUniquePurchaseOrderNumber() throws Exception {
        try {
			int orderId = getUniqueOrderId();
			String PONumber = "PO-" + String.valueOf(orderId);
			return PONumber;
        }
        catch (Exception e) {
            throw e;
        }
	}


    public boolean addOrder(String PONumber, String partSKU,int manufacturerId,int partQty) throws Exception {

        Statement stmt = null;
        ResultSet rs = null;

        try {
            //Get the Unique Purchase Order Id
            int orderId = getUniqueOrderId();

            //Get the PartId by finding the Part based on PartSKU
            SparePartDAO dao = new SparePartDAO(conn);
            SparePart part = dao.findByPartSKU(partSKU);

            //Insert the record in SPAREPARTORDER
            String currentDateTime = new java.util.Date().toString();
            StringBuffer InsertOrderSQL = new StringBuffer();
            InsertOrderSQL.append("INSERT INTO SPAREPARTPO VALUES (");
            InsertOrderSQL.append(orderId + ",");
            InsertOrderSQL.append("'" + PONumber + "',");
            InsertOrderSQL.append(part.getPartId() + ",");
            InsertOrderSQL.append(partQty + ",");
            InsertOrderSQL.append("'" + currentDateTime + "',");
            InsertOrderSQL.append(manufacturerId + ")");
            stmt = conn.createStatement();
            stmt.execute(InsertOrderSQL.toString());
            return true;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }

    }
}
