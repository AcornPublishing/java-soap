/*
 * CarModel.java
 *
 * Created on March 2, 2002, 10:38 AM
 */

package com.umw.entity;

/**
 *
 * @author  Administrator
 * @version 
 */
public class CarModel {

    /** Creates new CarModel */
    public CarModel() {
    }
    
    /** Getter for property modelDesc1.
     * @return Value of property modelDesc1.
     */
    public java.lang.String getModelDesc1() {
        return modelDesc1;
    }
    
    /** Setter for property modelDesc1.
     * @param modelDesc1 New value of property modelDesc1.
     */
    public void setModelDesc1(java.lang.String modelDesc1) {
        this.modelDesc1 = modelDesc1;
    }
    
    /** Getter for property modelDesc2.
     * @return Value of property modelDesc2.
     */
    public java.lang.String getModelDesc2() {
        return modelDesc2;
    }
    
    /** Setter for property modelDesc2.
     * @param modelDesc2 New value of property modelDesc2.
     */
    public void setModelDesc2(java.lang.String modelDesc2) {
        this.modelDesc2 = modelDesc2;
    }
    
    /** Getter for property modelDesc3.
     * @return Value of property modelDesc3.
     */
    public java.lang.String getModelDesc3() {
        return modelDesc3;
    }
    
    /** Setter for property modelDesc3.
     * @param modelDesc3 New value of property modelDesc3.
     */
    public void setModelDesc3(java.lang.String modelDesc3) {
        this.modelDesc3 = modelDesc3;
    }
    
    /** Getter for property modelId.
     * @return Value of property modelId.
     */
    public int getModelId() {
        return modelId;
    }
    
    /** Setter for property modelId.
     * @param modelId New value of property modelId.
     */
    public void setModelId(int modelId) {
        this.modelId = modelId;
    }
    
    /** Getter for property modelListPrice.
     * @return Value of property modelListPrice.
     */
    public float getModelListPrice() {
        return modelListPrice;
    }
    
    /** Setter for property modelListPrice.
     * @param modelListPrice New value of property modelListPrice.
     */
    public void setModelListPrice(float modelListPrice) {
        this.modelListPrice = modelListPrice;
    }
    
    /** Getter for property modelName.
     * @return Value of property modelName.
     */
    public java.lang.String getModelName() {
        return modelName;
    }
    
    /** Setter for property modelName.
     * @param modelName New value of property modelName.
     */
    public void setModelName(java.lang.String modelName) {
        this.modelName = modelName;
    }
    
    /** Getter for property modelYear.
     * @return Value of property modelYear.
     */
    public java.lang.String getModelYear() {
        return modelYear;
    }
    
    /** Setter for property modelYear.
     * @param modelYear New value of property modelYear.
     */
    public void setModelYear(java.lang.String modelYear) {
        this.modelYear = modelYear;
    }
    
    int modelId;
    String modelName;
    String modelDesc1;
    String modelDesc2;
    String modelDesc3;
    float  modelListPrice;

    String modelYear;
    
}
