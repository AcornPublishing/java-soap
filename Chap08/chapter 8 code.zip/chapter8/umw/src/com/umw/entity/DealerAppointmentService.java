/*
 * DealerAppointmentService.java
 *
 * Created on March 2, 2002, 9:58 AM
 */

package com.umw.entity;

/**
 *
 * @author  Administrator
 * @version 
 */
public class DealerAppointmentService {

    /** Creates new DealerAppointmentService */
    public DealerAppointmentService() {
    }
    
    /** Getter for property apppointmentServiceURL.
     * @return Value of property apppointmentServiceURL.
     */
    public java.lang.String getApppointmentServiceURL() {
        return apppointmentServiceURL;
    }
    
    /** Setter for property apppointmentServiceURL.
     * @param apppointmentServiceURL New value of property apppointmentServiceURL.
     */
    public void setApppointmentServiceURL(java.lang.String apppointmentServiceURL) {
        this.apppointmentServiceURL = apppointmentServiceURL;
    }
    
    /** Getter for property dealerId.
     * @return Value of property dealerId.
     */
    public int getDealerId() {
        return dealerId;
    }
    
    /** Setter for property dealerId.
     * @param dealerId New value of property dealerId.
     */
    public void setDealerId(int dealerId) {
        this.dealerId = dealerId;
    }
    
    int dealerId;
    String apppointmentServiceURL;

}
