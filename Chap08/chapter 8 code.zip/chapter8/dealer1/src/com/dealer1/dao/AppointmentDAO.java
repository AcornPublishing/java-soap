/*
 * AppointmentDAO.java
 *
 * Created on March 2, 2002, 5:45 AM
 */

package com.dealer1.dao;

import java.util.*;
import java.sql.*;
import com.dealer1.entity.*;
import com.dealer1.utils.*;

/**
 *
 * @author  Administrator
 * @version 
 */
public class AppointmentDAO {

    private Connection conn;

    /** Creates new AppointmentDAO */
    public AppointmentDAO(Connection conn) {
        this.conn = conn;
    }

    public ArrayList findAll() throws Exception {
        ArrayList appointmentList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM APPOINTMENT";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                Appointment appointment = new Appointment();
                appointment.setAppointmentId(rs.getInt("APPOINTMENTID"));
                appointment.setApptDate(rs.getString("APPTDATE"));
                appointment.setApptTime(rs.getString("APPTTIME"));
                appointment.setApptBooked(rs.getString("APPTBOOKED"));
                appointment.setCustomerName(rs.getString("CUSTOMERNAME"));
                appointmentList.add(appointment);
            }
            return appointmentList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public ArrayList findAppointmentsByType(boolean available) throws Exception {
        ArrayList appointmentList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer SQL = new StringBuffer();
        if (available) {
          SQL.append("SELECT * FROM APPOINTMENT WHERE APPTBOOKED='N'");
        }
        else {
          SQL.append("SELECT * FROM APPOINTMENT WHERE APPTBOOKED='Y'");
        }
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL.toString());
            while (rs.next()) {
                Appointment appointment = new Appointment();
                appointment.setAppointmentId(rs.getInt("APPOINTMENTID"));
                appointment.setApptDate(rs.getString("APPTDATE"));
                appointment.setApptTime(rs.getString("APPTTIME"));
                appointment.setApptBooked(rs.getString("APPTBOOKED"));
                appointment.setCustomerName(rs.getString("CUSTOMERNAME"));
                appointmentList.add(appointment);
            }
            return appointmentList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public boolean reserveAppointment(int appointmentId,String customerName) throws Exception {
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("UPDATE APPOINTMENT SET APPTBOOKED='Y', CUSTOMERNAME='");
        sql.append(customerName + "' WHERE APPOINTMENTID=");
        sql.append(String.valueOf(appointmentId));
        try {
            stmt = conn.createStatement();
            stmt.execute(sql.toString());
            return true;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }        
    }
    
    public Appointment findByPrimaryKey(int appointmentId) throws Exception {
        Appointment appointment = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM APPOINTMENT where APPOINTMENTID=");
        sql.append(String.valueOf(appointmentId));
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                appointment = new Appointment();
                appointment.setAppointmentId(rs.getInt("APPOINTMENTID"));
                appointment.setApptDate(rs.getString("APPTDATE"));
                appointment.setApptTime(rs.getString("APPTTIME"));
                appointment.setApptBooked(rs.getString("APPTBOOKED"));
                appointment.setCustomerName(rs.getString("CUSTOMERNAME"));
                return appointment;
            }
            else {
                throw new Exception("APPOINTMENT INFORMATION WAS NOT FOUND");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }        
    }

}
