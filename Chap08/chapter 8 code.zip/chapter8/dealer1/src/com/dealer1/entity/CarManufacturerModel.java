/*
 * CarMakerModel.java
 *
 * Created on March 2, 2002, 2:18 PM
 */

package com.dealer1.entity;

/**
 *
 * @author  Administrator
 * @version 
 */
public class CarManufacturerModel {

    /** Creates new CarMakerModel */
    public CarManufacturerModel() {
    }
    
    /** Getter for property modelId.
     * @return Value of property modelId.
     */
    public int getModelId() {
        return modelId;
    }
    
    /** Setter for property modelId.
     * @param modelId New value of property modelId.
     */
    public void setModelId(int modelId) {
        this.modelId = modelId;
    }
    
    /** Getter for property manufacturerId.
     * @return Value of property manufacturerId.
     */
    public int getManufacturerId() {
        return manufacturerId;
    }
    
    /** Setter for property manufacturerId.
     * @param manufacturerId New value of property manufacturerId.
     */
    public void setManufacturerId(int manufacturerId) {
        this.manufacturerId = manufacturerId;
    }
    
    int manufacturerId;
    int modelId;

}
