/*
 * SparePartOrder.java
 *
 * Created on March 2, 2002, 5:34 AM
 */

package com.umw.entity;

/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePartSO {

    /** Creates new SparePartOrder */
    public SparePartSO() {
    }

    /** Getter for property partId.
     * @return Value of property partId.
     */
    public int getPartId() {
        return partId;
    }
    
    /** Setter for property partId.
     * @param partId New value of property partId.
     */
    public void setPartId(int partId) {
        this.partId = partId;
    }
    
    /** Getter for property partQty.
     * @return Value of property partQty.
     */
    public int getPartQty() {
        return partQty;
    }
    
    /** Setter for property partQty.
     * @param partQty New value of property partQty.
     */
    public void setPartQty(int partQty) {
        this.partQty = partQty;
    }
    
    /** Getter for property orderDate.
     * @return Value of property orderDate.
     */
    public java.lang.String getOrderDate() {
        return orderDate;
    }
    
    /** Setter for property orderDate.
     * @param orderDate New value of property orderDate.
     */
    public void setOrderDate(java.lang.String orderDate) {
        this.orderDate = orderDate;
    }
    
    /** Getter for property dealerId.
     * @return Value of property dealerId.
     */
    public int getDealerId() {
        return dealerId;
    }
    
    /** Setter for property dealerId.
     * @param dealerId New value of property dealerId.
     */
    public void setDealerId(int dealerId) {
        this.dealerId = dealerId;
    }
    
    /** Getter for property SOId.
     * @return Value of property SOId.
     */
    public int getSOId() {
        return SOId;
    }
    
    /** Setter for property SOId.
     * @param SOId New value of property SOId.
     */
    public void setSOId(int SOId) {
        this.SOId = SOId;
    }
    
    /** Getter for property dealerPONum.
     * @return Value of property dealerPONum.
     */
    public java.lang.String getDealerPONum() {
        return dealerPONum;
    }
    
    /** Setter for property dealerPONum.
     * @param dealerPONum New value of property dealerPONum.
     */
    public void setDealerPONum(java.lang.String dealerPONum) {
        this.dealerPONum = dealerPONum;
    }
    
    int SOId;
    int partId;
    int dealerId;
    int partQty;
    String dealerPONum;
    String orderDate;
    
}
