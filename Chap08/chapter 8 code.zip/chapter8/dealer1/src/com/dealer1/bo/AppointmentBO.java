package com.dealer1.bo;
import java.util.*;
import java.sql.*;
import com.dealer1.dao.AppointmentDAO;
import com.dealer1.entity.Appointment;
import com.dealer1.utils.DBConnection;

public class AppointmentBO {

    public AppointmentBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            AppointmentDAO dao = new AppointmentDAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public ArrayList findAppointmentsByType(boolean available) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            AppointmentDAO dao = new AppointmentDAO(conn);
            return dao.findAppointmentsByType(available);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public boolean reserveAppointment(int apptId, String customerName) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            AppointmentDAO dao = new AppointmentDAO(conn);
            dao.reserveAppointment(apptId, customerName);
            return true;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public Appointment getAppointmentDetails(int apptId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            AppointmentDAO dao = new AppointmentDAO(conn);
            return dao.findByPrimaryKey(apptId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
