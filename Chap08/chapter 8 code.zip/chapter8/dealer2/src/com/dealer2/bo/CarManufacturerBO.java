/*
 * CarMakerBO.java
 *
 * Created on March 2, 2002, 7:15 AM
 */

package com.dealer2.bo;
import java.util.*;
import java.sql.*;
import com.dealer2.dao.CarManufacturerDAO;
import com.dealer2.entity.CarManufacturer;
import com.dealer2.utils.DBConnection;

/**
 *
 * @author  Administrator
 * @version 
 */
public class CarManufacturerBO {

    /** Creates new CarMakerBO */
    public CarManufacturerBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            CarManufacturerDAO dao = new CarManufacturerDAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public CarManufacturer getCarManufacturerDetails(int manufacturerId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            CarManufacturerDAO dao = new CarManufacturerDAO(conn);
            return dao.findByPrimaryKey(manufacturerId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public CarManufacturer findByDUNS(String DUNSNum) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            CarManufacturerDAO dao = new CarManufacturerDAO(conn);
            return dao.findByDUNS(DUNSNum);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

}
