/*
 * CarMakerBO.java
 *
 * Created on March 2, 2002, 7:15 AM
 */

package com.dealer1.bo;
import java.util.*;
import java.sql.*;
import com.dealer1.dao.CompanyMasterDAO;
import com.dealer1.entity.CompanyMaster;
import com.dealer1.utils.DBConnection;

/**
 *
 * @author  Administrator
 * @version 
 */
public class CompanyMasterBO {

    /** Creates new CarMakerBO */
    public CompanyMasterBO() {
    }

    public CompanyMaster getCompanyInfo() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            CompanyMasterDAO dao = new CompanyMasterDAO(conn);
            return dao.getCompanyInfo();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

}
