/*
 * SparePartOrderServiceBO.java
 *
 * Created on March 2, 2002, 7:17 AM
 */

package com.dealer2.bo;
import java.util.*;
import java.sql.*;
import com.dealer2.dao.SparePartOrderServiceDAO;
import com.dealer2.entity.SparePartOrderService;
import com.dealer2.utils.DBConnection;
/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePartOrderServiceBO {

    /** Creates new SparePartOrderServiceBO */
    public SparePartOrderServiceBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
          conn = DBConnection.getConnection();
          SparePartOrderServiceDAO dao = new SparePartOrderServiceDAO(conn);
          return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public SparePartOrderService getSparePartOrderServiceDetails(int manufacturerId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartOrderServiceDAO dao = new SparePartOrderServiceDAO(conn);
            return dao.findByPrimaryKey(manufacturerId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

}
