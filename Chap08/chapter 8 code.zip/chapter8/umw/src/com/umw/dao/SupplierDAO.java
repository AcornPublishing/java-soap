package com.umw.dao;

import java.util.*;
import java.sql.*;
import com.umw.entity.*;
import com.umw.utils.*;

public class SupplierDAO {
    
    private Connection conn;

    public SupplierDAO(Connection conn) {
        this.conn = conn;
    }
    
    public ArrayList findAll() throws Exception {
        ArrayList supplierList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM SUPPLIER";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                Supplier supplier = new Supplier();
                supplier.setSupplierId(rs.getInt("SUPPLIERID"));
                supplier.setSupplierName(rs.getString("SUPPLIERNAME"));
                supplier.setAddressLine1(rs.getString("ADDRESSLINE1"));
                supplier.setAddressLine2(rs.getString("ADDRESSLINE2"));
                supplier.setCity(rs.getString("CITY"));
                supplier.setState(rs.getString("STATE"));
                supplier.setZipCode(rs.getString("ZIPCODE"));
                supplier.setEmail(rs.getString("EMAIL"));
                supplier.setPhone(rs.getString("PHONE"));
                supplier.setFax(rs.getString("FAX"));
                supplier.setUserId(rs.getString("USERID"));
                supplier.setPassword(rs.getString("PASSWORD"));
                supplier.setDUNSNum(rs.getString("DUNSNUM"));
                supplierList.add(supplier);
            }
            return supplierList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public Supplier findByPrimaryKey(int supplierId) throws Exception {
        Supplier supplier = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM SUPPLIER where SUPPLIERID=");
        sql.append(String.valueOf(supplierId));
        
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                supplier = new Supplier();
                supplier.setSupplierId(rs.getInt("SUPPLIERID"));
                supplier.setSupplierName(rs.getString("SUPPLIERNAME"));
                supplier.setAddressLine1(rs.getString("ADDRESSLINE1"));
                supplier.setAddressLine2(rs.getString("ADDRESSLINE2"));
                supplier.setCity(rs.getString("CITY"));
                supplier.setState(rs.getString("STATE"));
                supplier.setZipCode(rs.getString("ZIPCODE"));
                supplier.setEmail(rs.getString("EMAIL"));
                supplier.setPhone(rs.getString("PHONE"));
                supplier.setFax(rs.getString("FAX"));
                supplier.setDUNSNum(rs.getString("DUNSNUM"));
                return supplier;
            }
            else {
                throw new Exception("SUPPLIER RECORD IS NOT PRESENT IN DATABASE");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
