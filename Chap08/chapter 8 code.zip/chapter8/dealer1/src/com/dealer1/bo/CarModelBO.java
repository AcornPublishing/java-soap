package com.dealer1.bo;
import java.util.*;
import java.sql.*;
import com.dealer1.dao.CarModelDAO;
import com.dealer1.entity.CarModel;
import com.dealer1.utils.DBConnection;

public class CarModelBO {

    public CarModelBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            CarModelDAO dao = new CarModelDAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public CarModel getCarModelDetails(int modelId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            CarModelDAO dao = new CarModelDAO(conn);
            return dao.findByPrimaryKey(modelId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
