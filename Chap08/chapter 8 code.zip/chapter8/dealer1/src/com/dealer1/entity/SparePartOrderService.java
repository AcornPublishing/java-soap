/*
 * SparePartOrderService.java
 *
 * Created on March 2, 2002, 2:20 PM
 */

package com.dealer1.entity;

/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePartOrderService {

    /** Creates new SparePartOrderService */
    public SparePartOrderService() {
    }
    
    /** Getter for property orderServiceURL.
     * @return Value of property orderServiceURL.
     */
    public java.lang.String getOrderServiceURL() {
        return orderServiceURL;
    }
    
    /** Setter for property orderServiceURL.
     * @param orderServiceURL New value of property orderServiceURL.
     */
    public void setOrderServiceURL(java.lang.String orderServiceURL) {
        this.orderServiceURL = orderServiceURL;
    }
    
    /** Getter for property manufacturerId.
     * @return Value of property manufacturerId.
     */
    public int getManufacturerId() {
        return manufacturerId;
    }
    
    /** Setter for property manufacturerId.
     * @param manufacturerId New value of property manufacturerId.
     */
    public void setManufacturerId(int manufacturerId) {
        this.manufacturerId = manufacturerId;
    }
    
    int manufacturerId;
    String orderServiceURL;

}
