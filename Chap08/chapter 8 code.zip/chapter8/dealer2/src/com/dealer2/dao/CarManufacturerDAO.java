/*
 * CarMakerDAO.java
 *
 * Created on March 2, 2002, 5:44 AM
 */

package com.dealer2.dao;

import java.util.*;
import java.sql.*;
import com.dealer2.entity.*;
import com.dealer2.utils.*;

/**
 *
 * @author  Administrator
 * @version 
 */
public class CarManufacturerDAO {
    
    private Connection conn;

    /** Creates new CarMakerDAO */
    public CarManufacturerDAO(Connection conn) {
        this.conn = conn;
    }
    
    public ArrayList findAll() throws Exception {
        ArrayList carMakerList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM CARMANUFACTURER";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                CarManufacturer maker = new CarManufacturer();
                maker.setManufacturerId(rs.getInt("MANUFACTURERID"));
                maker.setCarMakerName(rs.getString("NAME"));
                maker.setAddressLine1(rs.getString("ADDRESSLINE1"));
                maker.setAddressLine2(rs.getString("ADDRESSLINE2"));
                maker.setCity(rs.getString("CITY"));
                maker.setState(rs.getString("STATE"));
                maker.setZipCode(rs.getString("ZIPCODE"));
                maker.setEmail(rs.getString("EMAIL"));
                maker.setPhone(rs.getString("PHONE"));
                maker.setFax(rs.getString("FAX"));
                maker.setDUNSNum(rs.getString("DUNSNUM"));
                carMakerList.add(maker);
            }
            return carMakerList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public CarManufacturer findByPrimaryKey(int manufacturerId) throws Exception {
        CarManufacturer maker = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM CARMANUFACTURER where MANUFACTURERID=");
        sql.append(String.valueOf(manufacturerId));
        
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                maker = new CarManufacturer();
                maker.setManufacturerId(rs.getInt("MANUFACTURERID"));
                maker.setCarMakerName(rs.getString("CARMAKERNAME"));
                maker.setAddressLine1(rs.getString("ADDRESSLINE1"));
                maker.setAddressLine2(rs.getString("ADDRESSLINE2"));
                maker.setCity(rs.getString("CITY"));
                maker.setState(rs.getString("STATE"));
                maker.setZipCode(rs.getString("ZIPCODE"));
                maker.setEmail(rs.getString("EMAIL"));
                maker.setPhone(rs.getString("PHONE"));
                maker.setFax(rs.getString("FAX"));
                maker.setDUNSNum(rs.getString("DUNSNUM"));
                return maker;
            }
            else {
                throw new Exception("MANUFACTURER RECORD IS NOT PRESENT IN DATABASE");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    public CarManufacturer findByDUNS(String DUNSNum) throws Exception {
        CarManufacturer maker = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM CARMANUFACTURER where DUNSNUM=");
        sql.append(DUNSNum);
        
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                maker = new CarManufacturer();
                maker.setManufacturerId(rs.getInt("MANUFACTURERID"));
                maker.setCarMakerName(rs.getString("CARMAKERNAME"));
                maker.setAddressLine1(rs.getString("ADDRESSLINE1"));
                maker.setAddressLine2(rs.getString("ADDRESSLINE2"));
                maker.setCity(rs.getString("CITY"));
                maker.setState(rs.getString("STATE"));
                maker.setZipCode(rs.getString("ZIPCODE"));
                maker.setEmail(rs.getString("EMAIL"));
                maker.setPhone(rs.getString("PHONE"));
                maker.setFax(rs.getString("FAX"));
                maker.setDUNSNum(rs.getString("DUNSNUM"));
                return maker;
            }
            else {
                throw new Exception("MANUFACTURER RECORD IS NOT PRESENT IN DATABASE");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
}
