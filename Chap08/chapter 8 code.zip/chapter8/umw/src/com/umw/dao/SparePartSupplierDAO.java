package com.umw.dao;

import java.util.*;
import java.sql.*;
import com.umw.entity.*;
import com.umw.utils.*;

public class SparePartSupplierDAO {
    
    private Connection conn;

    public SparePartSupplierDAO(Connection conn) {
        this.conn = conn;
    }
    
    public ArrayList findAll() throws Exception {
        ArrayList partsupplierList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM SPAREPARTSUPPLIER";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                SparePartSupplier partSupplier = new SparePartSupplier();
                partSupplier.setPartId(rs.getInt("PARTID"));
                partSupplier.setSupplierId(rs.getInt("SUPPLIERID"));
                partsupplierList.add(partSupplier);
            }
            return partsupplierList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public ArrayList findAllSuppliersByPart(int partId) throws Exception {
        ArrayList partsupplierList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer SQL = new StringBuffer();
        SQL.append("SELECT * FROM SPAREPARTSUPPLIER WHERE PARTID=");
        SQL.append(String.valueOf(partId));
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL.toString());
            while (rs.next()) {
                SparePartSupplier partSupplier = new SparePartSupplier();
                partSupplier.setPartId(rs.getInt("PARTID"));
                partSupplier.setSupplierId(rs.getInt("SUPPLIERID"));
                partsupplierList.add(partSupplier);
            }
            return partsupplierList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public ArrayList findAllPartsBySupplier(int supplierId) throws Exception {
        ArrayList partsupplierList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer SQL = new StringBuffer();
        SQL.append("SELECT * FROM SPAREPARTSUPPLIER WHERE SUPPLIERID=");
        SQL.append(String.valueOf(supplierId));
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL.toString());
            while (rs.next()) {
                SparePartSupplier partSupplier = new SparePartSupplier();
                partSupplier.setPartId(rs.getInt("PARTID"));
                partSupplier.setSupplierId(rs.getInt("SUPPLIERID"));
                partsupplierList.add(partSupplier);
            }
            return partsupplierList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

}
