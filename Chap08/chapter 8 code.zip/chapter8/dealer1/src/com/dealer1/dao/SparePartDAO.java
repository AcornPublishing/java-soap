/*
 * SparePartDAO.java
 *
 * Created on March 2, 2002, 5:45 AM
 */

package com.dealer1.dao;

import java.util.*;
import java.sql.*;
import com.dealer1.entity.*;
import com.dealer1.utils.*;

/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePartDAO {

    private Connection conn;

    /** Creates new SparePartDAO */
    public SparePartDAO(Connection conn) {
        this.conn = conn;
    }

    public ArrayList findAll() throws Exception {
        ArrayList sparePartList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM SPAREPART";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                SparePart part = new SparePart();
                part.setPartId(rs.getInt("PARTID"));
                part.setPartSKU(rs.getString("PARTSKU"));
                part.setPartName(rs.getString("PARTNAME"));
                part.setPartPrice(rs.getFloat("PARTPRICE"));
                part.setManufacturerId(rs.getInt("MANUFACTURERID"));
                sparePartList.add(part);
            }
            return sparePartList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public SparePart findByPrimaryKey(int partId) throws Exception {
        SparePart part = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM SPAREPART where PARTID=");
        sql.append(String.valueOf(partId));
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                part = new SparePart();
                part.setPartId(rs.getInt("PARTID"));
                part.setPartSKU(rs.getString("PARTSKU"));
                part.setPartName(rs.getString("PARTNAME"));
                part.setPartPrice(rs.getFloat("PARTPRICE"));
                part.setManufacturerId(rs.getInt("MANUFACTURERID"));
                return part;
            }
            else {
                throw new Exception("SPAREPART INFORMATION WAS NOT FOUND");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }        
    }

    public SparePart findByPartSKU(String partSKU) throws Exception {
        SparePart part = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM SPAREPART where PARTSKU='");
        sql.append(partSKU);
        sql.append("'");
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                part = new SparePart();
                part.setPartId(rs.getInt("PARTID"));
                part.setPartSKU(rs.getString("PARTSKU"));
                part.setPartName(rs.getString("PARTNAME"));
                part.setPartPrice(rs.getFloat("PARTPRICE"));
                part.setManufacturerId(rs.getInt("MANUFACTURERID"));
                return part;
            }
            else {
                throw new Exception("SPAREPART INFORMATION WAS NOT FOUND");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }        
    }
}
