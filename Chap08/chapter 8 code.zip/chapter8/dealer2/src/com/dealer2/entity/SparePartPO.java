/*
 * SparePartOrder.java
 *
 * Created on March 2, 2002, 5:34 AM
 */

package com.dealer2.entity;

/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePartPO {

    /** Creates new SparePartOrder */
    public SparePartPO() {
    }

    /** Getter for property partId.
     * @return Value of property partId.
     */
    public int getPartId() {
        return partId;
    }
    
    /** Setter for property partId.
     * @param partId New value of property partId.
     */
    public void setPartId(int partId) {
        this.partId = partId;
    }
    
    /** Getter for property partQty.
     * @return Value of property partQty.
     */
    public int getPartQty() {
        return partQty;
    }
    
    /** Setter for property partQty.
     * @param partQty New value of property partQty.
     */
    public void setPartQty(int partQty) {
        this.partQty = partQty;
    }
    
    /** Getter for property orderDate.
     * @return Value of property orderDate.
     */
    public java.lang.String getOrderDate() {
        return orderDate;
    }
    
    /** Setter for property orderDate.
     * @param orderDate New value of property orderDate.
     */
    public void setOrderDate(java.lang.String orderDate) {
        this.orderDate = orderDate;
    }
    
    /** Getter for property POId.
     * @return Value of property POId.
     */
    public int getPOId() {
        return POId;
    }
    
    /** Setter for property POId.
     * @param POId New value of property POId.
     */
    public void setPOId(int POId) {
        this.POId = POId;
    }
    
    /** Getter for property manufacturerId.
     * @return Value of property manufacturerId.
     */
    public int getManufacturerId() {
        return manufacturerId;
    }
    
    /** Setter for property manufacturerId.
     * @param manufacturerId New value of property manufacturerId.
     */
    public void setManufacturerId(int manufacturerId) {
        this.manufacturerId = manufacturerId;
    }
    
    /** Getter for property PONumber.
     * @return Value of property PONumber.
     */
    public java.lang.String getPONumber() {
        return PONumber;
    }
    
    /** Setter for property PONumber.
     * @param PONumber New value of property PONumber.
     */
    public void setPONumber(java.lang.String PONumber) {
        this.PONumber = PONumber;
    }
    
    int POId;
    String PONumber;
    int partId;
    int manufacturerId;
    int partQty;
    
    public String orderDate;
    
}
