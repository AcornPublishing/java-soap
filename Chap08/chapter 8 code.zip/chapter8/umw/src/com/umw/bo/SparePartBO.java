/*
 * SparePartBO.java
 *
 * Created on March 2, 2002, 7:15 AM
 */

package com.umw.bo;
import java.util.*;
import java.sql.*;
import com.umw.dao.SparePartDAO;
import com.umw.entity.SparePart;
import com.umw.utils.DBConnection;

/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePartBO {

    /** Creates new SparePartBO */
    public SparePartBO() {
    }
    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartDAO dao = new SparePartDAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public SparePart getSparePartDetails(int partId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartDAO dao = new SparePartDAO(conn);
            return dao.findByPrimaryKey(partId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public SparePart findByPartSKU(String partSKU) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartDAO dao = new SparePartDAO(conn);
            return dao.findByPartSKU(partSKU);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
