package com.umw.bo;
import java.util.*;
import java.sql.*;
import com.umw.dao.SparePartSupplierDAO;
import com.umw.entity.SparePartSupplier;
import com.umw.utils.DBConnection;

public class SparePartSupplierBO {

    public SparePartSupplierBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartSupplierDAO dao = new SparePartSupplierDAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public ArrayList findAllSuppliersByPart(int partId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartSupplierDAO dao = new SparePartSupplierDAO(conn);
            return dao.findAllSuppliersByPart(partId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public ArrayList findAllPartsBySupplier(int supplierId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartSupplierDAO dao = new SparePartSupplierDAO(conn);
            return dao.findAllPartsBySupplier(supplierId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
