/*
 * SparePartOrderBO.java
 *
 * Created on March 2, 2002, 7:16 AM
 */

package com.dealer1.bo;
import java.util.*;
import java.sql.*;
import com.dealer1.dao.SparePartPODAO;
import com.dealer1.entity.SparePartPO;
import com.dealer1.utils.DBConnection;
/**
 *
 * @author  Administrator
 * @version
 */
public class SparePartPOBO {

    /** Creates new SparePartOrderBO */
    public SparePartPOBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartPODAO dao = new SparePartPODAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public SparePartPO getSparePartPODetails(int POId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartPODAO dao = new SparePartPODAO(conn);
            return dao.findByPrimaryKey(POId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public String getUniquePurchaseOrderNumber() throws Exception {
		Connection conn = null;
        try {
			conn = DBConnection.getConnection();
            SparePartPODAO dao = new SparePartPODAO(conn);
            return dao.getUniquePurchaseOrderNumber();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
	}


    public boolean addOrder(String PONumber, String partSKU ,int manufacturerId, int partQty) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartPODAO dao = new SparePartPODAO(conn);
            return dao.addOrder(PONumber, partSKU, manufacturerId, partQty);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
