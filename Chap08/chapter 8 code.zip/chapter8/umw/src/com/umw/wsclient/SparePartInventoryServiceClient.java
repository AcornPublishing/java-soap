package com.umw.wsclient;
import java.net.URL;
import org.apache.axis.client.Service;
import org.apache.axis.client.Call;
import org.apache.axis.encoding.XMLType;

import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.namespace.QName;
import org.apache.axis.encoding.ser.BeanSerializerFactory;
import org.apache.axis.encoding.ser.BeanDeserializerFactory;

import com.umw.entity.SparePartInventory;

public class SparePartInventoryServiceClient {

    /** Creates new SparePartInventoryClient */
    public SparePartInventoryServiceClient() {
    }

    public SparePartInventory getInventoryDetails(int partId) throws Exception {
        try {

              String endpointURL = "http://localhost:7080/UMW/services/SparePartInventoryService";
              String methodName  = "getInventoryDetails";

              // Create the Service call
              Service service = new Service();
              Call call = (Call) service.createCall();
              call.setTargetEndpointAddress(new java.net.URL(endpointURL));
              call.setOperationName(new QName("SparePartInventoryService",methodName));
              call.addParameter("partid",XMLType.XSD_INT,ParameterMode.PARAM_MODE_IN);

              QName qname = new QName("SparePartInventoryService", "SparePartInventory");
              Class cls = com.umw.entity.SparePartInventory.class;
	      call.registerTypeMapping(cls, qname, BeanSerializerFactory.class, BeanDeserializerFactory.class);
              call.setReturnType(qname);

              //Integer partId = new Integer(partId);
              Object[] params = new Object[] { new Integer(partId) };

              //Invoke the SparePartPrice Web Service
              SparePartInventory InvBean = (SparePartInventory) call.invoke(params);
              return InvBean;

        }
        catch (Exception e) {
            throw e;
        }
    }

    public static void main(String[] args) throws Exception {
        SparePartInventoryServiceClient client = new SparePartInventoryServiceClient();
        SparePartInventory inv = client.getInventoryDetails(1);
        System.out.println(inv.getPartId() + "-" + inv.getQtyOnHand());
    }
}
