package com.dealer1.bo;
import java.util.*;
import java.sql.*;
import com.dealer1.dao.CarManufacturerModelDAO;
import com.dealer1.entity.CarManufacturerModel;
import com.dealer1.utils.DBConnection;

public class CarManufacturerModelBO {

    public CarManufacturerModelBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            CarManufacturerModelDAO dao = new CarManufacturerModelDAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public ArrayList findAllModelsByManufacturer(int manufacturerId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            CarManufacturerModelDAO dao = new CarManufacturerModelDAO(conn);
            return dao.findAllModelsByManufacturer(manufacturerId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

}
