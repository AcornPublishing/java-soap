/**
 * SparePartDescription.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis Wsdl2java emitter.
 */

package wroxaxis.chapter2.skeleton;

public interface SparePartDescription extends java.rmi.Remote {
    public java.lang.String getDescription(java.lang.String in0) throws java.rmi.RemoteException;
}
