package com.dealer2.bo;
import java.util.*;
import java.sql.*;
import com.dealer2.dao.SparePartInventoryDAO;
import com.dealer2.entity.SparePartInventory;
import com.dealer2.utils.DBConnection;

public class SparePartInventoryBO {

    public SparePartInventoryBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartInventoryDAO dao = new SparePartInventoryDAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public SparePartInventory getInventoryDetails(int partId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartInventoryDAO dao = new SparePartInventoryDAO(conn);
            return dao.findByPrimaryKey(partId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
