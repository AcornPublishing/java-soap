/*
 * Appointment.java
 *
 * Created on March 2, 2002, 2:24 PM
 */

package com.dealer1.entity;

/**
 *
 * @author  Administrator
 * @version 
 */
public class Appointment {

    /** Creates new Appointment */
    public Appointment() {
    }
    
    /** Getter for property appointmentId.
     * @return Value of property appointmentId.
     */
    public int getAppointmentId() {
        return appointmentId;
    }
    
    /** Setter for property appointmentId.
     * @param appointmentId New value of property appointmentId.
     */
    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }
    
    /** Getter for property apptBooked.
     * @return Value of property apptBooked.
     */
    public java.lang.String getApptBooked() {
        return apptBooked;
    }
    
    /** Setter for property apptBooked.
     * @param apptBooked New value of property apptBooked.
     */
    public void setApptBooked(java.lang.String apptBooked) {
        this.apptBooked = apptBooked;
    }
    
    /** Getter for property apptDate.
     * @return Value of property apptDate.
     */
    public java.lang.String getApptDate() {
        return apptDate;
    }
    
    /** Setter for property apptDate.
     * @param apptDate New value of property apptDate.
     */
    public void setApptDate(java.lang.String apptDate) {
        this.apptDate = apptDate;
    }
    
    /** Getter for property apptTime.
     * @return Value of property apptTime.
     */
    public java.lang.String getApptTime() {
        return apptTime;
    }
    
    /** Setter for property apptTime.
     * @param apptTime New value of property apptTime.
     */
    public void setApptTime(java.lang.String apptTime) {
        this.apptTime = apptTime;
    }
    
    /** Getter for property customerName.
     * @return Value of property customerName.
     */
    public java.lang.String getCustomerName() {
        return customerName;
    }
    
    /** Setter for property customerName.
     * @param customerName New value of property customerName.
     */
    public void setCustomerName(java.lang.String customerName) {
        this.customerName = customerName;
    }
    
    int appointmentId;
    String apptDate;
    String apptTime;
    String apptBooked;
    String customerName;

}
