package com.umw.dao;

import java.util.*;
import java.sql.*;
import com.umw.entity.*;
import com.umw.utils.*;

public class DealerDAO {
    
    private Connection conn;

    public DealerDAO(Connection conn) {
        this.conn = conn;
    }
    
    public ArrayList findAll() throws Exception {
        ArrayList dealerList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM DEALER";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                Dealer dealer = new Dealer();
                dealer.setDealerId(rs.getInt("DEALERID"));
                dealer.setDealerName(rs.getString("DEALERNAME"));
                dealer.setAddressLine1(rs.getString("ADDRESSLINE1"));
                dealer.setAddressLine2(rs.getString("ADDRESSLINE2"));
                dealer.setCity(rs.getString("CITY"));
                dealer.setState(rs.getString("STATE"));
                dealer.setZipCode(rs.getString("ZIPCODE"));
                dealer.setEmail(rs.getString("EMAIL"));
                dealer.setPhone(rs.getString("PHONE"));
                dealer.setFax(rs.getString("FAX"));
                dealer.setDUNSNum(rs.getString("DUNSNUM"));
                dealerList.add(dealer);
            }
            return dealerList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public Dealer findByPrimaryKey(int dealerId) throws Exception {
        Dealer dealer = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM DEALER where DEALERID=");
        sql.append(String.valueOf(dealerId));
        
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                dealer = new Dealer();
                dealer.setDealerId(rs.getInt("DEALERID"));
                dealer.setDealerName(rs.getString("DEALERNAME"));
                dealer.setAddressLine1(rs.getString("ADDRESSLINE1"));
                dealer.setAddressLine2(rs.getString("ADDRESSLINE2"));
                dealer.setCity(rs.getString("CITY"));
                dealer.setState(rs.getString("STATE"));
                dealer.setZipCode(rs.getString("ZIPCODE"));
                dealer.setEmail(rs.getString("EMAIL"));
                dealer.setPhone(rs.getString("PHONE"));
                dealer.setFax(rs.getString("FAX"));
                dealer.setDUNSNum(rs.getString("DUNSNUM"));
                return dealer;
            }
            else {
                throw new Exception("DEALER RECORD IS NOT PRESENT IN DATABASE");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    public Dealer findByDUNS(String DUNSNum) throws Exception {
        Dealer dealer = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM DEALER where DUNSNUM=");
        sql.append(DUNSNum);
        
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                dealer = new Dealer();
                dealer.setDealerId(rs.getInt("DEALERID"));
                dealer.setDealerName(rs.getString("DEALERNAME"));
                dealer.setAddressLine1(rs.getString("ADDRESSLINE1"));
                dealer.setAddressLine2(rs.getString("ADDRESSLINE2"));
                dealer.setCity(rs.getString("CITY"));
                dealer.setState(rs.getString("STATE"));
                dealer.setZipCode(rs.getString("ZIPCODE"));
                dealer.setEmail(rs.getString("EMAIL"));
                dealer.setPhone(rs.getString("PHONE"));
                dealer.setFax(rs.getString("FAX"));
                dealer.setDUNSNum(rs.getString("DUNSNUM"));
                return dealer;
            }
            else {
                throw new Exception("INCORRECT DUNS Number for Dealer");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

}
