/*
 * CarMakerDAO.java
 *
 * Created on March 2, 2002, 5:44 AM
 */

package com.dealer1.dao;

import java.util.*;
import java.sql.*;
import com.dealer1.entity.*;
import com.dealer1.utils.*;

/**
 *
 * @author  Administrator
 * @version 
 */
public class CompanyMasterDAO {
    
    private Connection conn;

    /** Creates new CarMakerDAO */
    public CompanyMasterDAO(Connection conn) {
        this.conn = conn;
    }
    
    public  CompanyMaster getCompanyInfo() throws Exception {
        CompanyMaster company = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM COMPANYMASTER");
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                company = new CompanyMaster();
                company.setName(rs.getString("NAME"));
                company.setAddressLine1(rs.getString("ADDRESSLINE1"));
                company.setAddressLine2(rs.getString("ADDRESSLINE2"));
                company.setCity(rs.getString("CITY"));
                company.setState(rs.getString("STATE"));
                company.setZipCode(rs.getString("ZIPCODE"));
                company.setEmail(rs.getString("EMAIL"));
                company.setPhone(rs.getString("PHONE"));
                company.setFax(rs.getString("FAX"));
                company.setDUNSNum(rs.getString("DUNSNUM"));
                return company;
            }
            else {
                throw new Exception("COMPANY RECORD IS NOT PRESENT IN DATABASE");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }

    
}
