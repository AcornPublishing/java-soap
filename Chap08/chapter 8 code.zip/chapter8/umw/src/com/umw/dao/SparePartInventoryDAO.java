package com.umw.dao;

import java.util.*;
import java.sql.*;
import com.umw.entity.*;
import com.umw.utils.*;

public class SparePartInventoryDAO {
    
    private Connection conn;

    public SparePartInventoryDAO(Connection conn) {
        this.conn = conn;
    }
    
    public ArrayList findAll() throws Exception {
        ArrayList invList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM SPAREPARTINVENTORY";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                SparePartInventory inv = new SparePartInventory();
                inv.setPartId(rs.getInt("PARTID"));
                inv.setQtyOnHand(rs.getInt("QTYONHAND"));
                inv.setReorderLevel(rs.getInt("REORDERLEVEL"));
                inv.setMinOrderQty(rs.getInt("MINORDERQTY"));
                invList.add(inv);
            }
            return invList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public SparePartInventory findByPrimaryKey(int partId) throws Exception {
        SparePartInventory inv = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM SPAREPARTINVENTORY where PARTID=");
        sql.append(String.valueOf(partId));
        
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                inv = new SparePartInventory();
                inv.setPartId(rs.getInt("PARTID"));
                inv.setQtyOnHand(rs.getInt("QTYONHAND"));
                inv.setReorderLevel(rs.getInt("REORDERLEVEL"));
                inv.setMinOrderQty(rs.getInt("MINORDERQTY"));
                return inv;
            }
            else {
                throw new Exception("SPAREPART INVENTORY RECORD IS NOT PRESENT IN DATABASE");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
