/*
 * InventoryServiceDAO.java
 *
 * Created on March 2, 2002, 5:44 AM
 */

package com.umw.dao;
import java.util.*;
import java.sql.*;
import com.umw.entity.*;
import com.umw.utils.*;

/**
 *
 * @author  Administrator
 * @version 
 */
public class DealerAppointmentServiceDAO {

    private Connection conn;

    public DealerAppointmentServiceDAO(Connection conn) {
        this.conn = conn;
    }
    public ArrayList findAll() throws Exception {
        ArrayList apptServiceList = new ArrayList();
        Statement stmt = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM DEALERAPPOINTMENTSERVICE";
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                DealerAppointmentService apptService = new DealerAppointmentService();
                apptService.setDealerId(rs.getInt("DEALERID"));
                apptService.setApppointmentServiceURL(rs.getString("APPOINTMENTSERVICEURL"));
                apptServiceList.add(apptService);
            }
            return apptServiceList;
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }

        }
    }
    
    public DealerAppointmentService findByPrimaryKey(int dealerId) throws Exception {
        DealerAppointmentService apptService = null;
        Statement stmt = null;
        ResultSet rs = null;
        StringBuffer sql = new StringBuffer();
        sql.append("SELECT * FROM DEALERAPPOINTMENTSERVICE where DEALERID=");
        sql.append(String.valueOf(dealerId));
        try {
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql.toString());
            if (rs.next()) {
                apptService = new DealerAppointmentService();
                apptService.setDealerId(rs.getInt("DEALERID"));
                apptService.setApppointmentServiceURL(rs.getString("APPOINTMENTSERVICEURL"));
                return apptService;
            }
            else {
                throw new Exception("APPOINTMENT SERVICE INFORMATION WAS NOT FOUND");
            }
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
