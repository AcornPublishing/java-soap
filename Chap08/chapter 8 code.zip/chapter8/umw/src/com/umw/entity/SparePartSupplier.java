/*
 * SparePartSupplier.java
 *
 * Created on March 2, 2002, 9:59 AM
 */

package com.umw.entity;

/**
 *
 * @author  Administrator
 * @version 
 */
public class SparePartSupplier {

    /** Creates new SparePartSupplier */
    public SparePartSupplier() {
    }
    
    /** Getter for property partId.
     * @return Value of property partId.
     */
    public int getPartId() {
        return partId;
    }
    
    /** Setter for property partId.
     * @param partId New value of property partId.
     */
    public void setPartId(int partId) {
        this.partId = partId;
    }
    
    /** Getter for property supplierId.
     * @return Value of property supplierId.
     */
    public int getSupplierId() {
        return supplierId;
    }
    
    /** Setter for property supplierId.
     * @param supplierId New value of property supplierId.
     */
    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }
    
    int supplierId;
    int partId;

}
