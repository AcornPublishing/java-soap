package com.umw.bo;
import java.util.*;
import java.sql.*;
import com.umw.dao.SparePartInventoryDAO;
import com.umw.entity.SparePartInventory;
import com.umw.utils.DBConnection;

public class SparePartInventoryBO {

    public SparePartInventoryBO() {
    }

    public ArrayList findAll() throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartInventoryDAO dao = new SparePartInventoryDAO(conn);
            return dao.findAll();
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
    
    public SparePartInventory getInventoryDetails(int partId) throws Exception {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            SparePartInventoryDAO dao = new SparePartInventoryDAO(conn);
            return dao.findByPrimaryKey(partId);
        }
        catch (Exception e) {
            throw e;
        }
        finally {
            try {
                if (conn != null) conn.close();
            }
            catch (Exception e) {
                throw e;
            }
        }
    }
}
